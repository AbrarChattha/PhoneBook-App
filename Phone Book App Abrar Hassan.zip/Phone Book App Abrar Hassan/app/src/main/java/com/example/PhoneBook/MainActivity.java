package com.example.PhoneBook;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView lv;
    EditText ed;

    SharedPreferences spname;
    SharedPreferences spnumber;
    static List<String> li = new ArrayList<String>();;       //(this.li) after static it become (mainactivity.li)
    static List<String> phonenumber = new ArrayList<String>();;
    static int firsttime = 0;
    static ArrayAdapter<String> aA;


    static int selectedpositionforedit = 0;
    static int lastselecteditemnumber = 0;
    static int pehlidafachalana = 0;
    static String lastselectedvalue = "";

    EditText etnumber,etname;
    int selecteditem = -1;
    int selectionkliyejhanda = 0;

    public void savekrnykliye(View kuchb){

         String namewalistring = etname.getText().toString();
         String numberwalistring = etnumber.getText().toString();

         li.add(namewalistring);
         phonenumber.add(numberwalistring);
        aA.notifyDataSetChanged();
         Toast.makeText(this, "Contact added", Toast.LENGTH_SHORT).show();


    }



    public void daletekrnykliye(View kuchb){
       if(selectionkliyejhanda == 1) {
           li.remove(selecteditem);
           phonenumber.remove(selecteditem);
           Toast.makeText(this, "Contact deleted", Toast.LENGTH_SHORT).show();
       }
        aA.notifyDataSetChanged();              //this is notification for gui from array attatch both of them



    }

    public void nawiactivity(View kuchb){
        Intent nayapage = new Intent(this,Main2Activity.class);
        startActivity(nayapage);



    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        lv =findViewById(R.id.listview);


         ed = findViewById(R.id.kuchnaam);
        etname = findViewById(R.id.editTextname);
        etnumber = findViewById(R.id.editTextnumber);





         li = new ArrayList<String>();  //array of linklist
        phonenumber = new ArrayList<String>();

                                          // all type of data add but when we write <String> then weonly save string type data
                                           //li.add(2);

        spname = this.getSharedPreferences("com.example.phonebook ahsan", Context.MODE_PRIVATE);



       if (firsttime == 0) {


           li.add("Abrar Hassan");
           phonenumber.add("03163345666");
           li.add("Waqar Ali");
           phonenumber.add("03160022344");
           li.add("sir");
           phonenumber.add("03134566677");
           li.add("zulfiqar Ali Bungash");
           phonenumber.add("031345567776");
           li.add("ali hassan");
           phonenumber.add("034455667774");
           li.add("Arslan ali");
           phonenumber.add("031602330006");
           li.add("Hassan");
           phonenumber.add("03160034007");
           li.add("CEO ");
           phonenumber.add("031600000234");
           li.add("Iqra uni");
           phonenumber.add("092344556676");
           li.add("Steve ");
           phonenumber.add("03160002330");
           li.add(" Cook");
           phonenumber.add("03233455566");
           li.add("Bill Gates");
           phonenumber.add("031600334012");
           li.add("Ali");
           phonenumber.add("031600012313");
           li.add("Imran Khan");
           phonenumber.add("03160000015");
           li.add("Shahzad");
           phonenumber.add("03160000017");
           li.add("virat");
           phonenumber.add("03190000019");
           li.add("Mama");
           phonenumber.add("0316003417");
           li.add("Awais");
           phonenumber.add("03160000020");
           li.add("Talib Saeed");
           phonenumber.add("03160002344");
           li.add(" Asif");
           phonenumber.add("031600002320");
           li.add("Major Aamir ");
           phonenumber.add("031600000233");
       }
        li.remove(2);                        //we can remove/delete andy indax data and also save memeory

                                               //retrive data by using log
                                               //Log.i("data",li.get(0));


                                             // this is "bridge" to communicate two diff entities(listview & data)
        aA = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,li);

        aA = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, li);
        lv.setAdapter(aA);      //attach with gui

      lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                 selectedpositionforedit = position;
              if (position == lastselecteditemnumber){
                  spname.edit().putString(String.valueOf(lastselecteditemnumber), lastselectedvalue).apply();
                  li.set(lastselecteditemnumber, lastselectedvalue);
              }
              Intent naiActivity = new Intent(getApplicationContext(),Main3Activity.class);
                naiActivity = new Intent(getApplicationContext(), Main3Activity.class);
               naiActivity.putExtra("aikKey",position);  //send this position on activity4 without using static
              startActivity(naiActivity);


                li.remove(position);
                phonenumber.remove(position);
                aA.notifyDataSetChanged();
               if (position == lastselecteditemnumber)
                    pehlidafachalana = 0;
               else if (position < lastselecteditemnumber)
                   lastselecteditemnumber = lastselecteditemnumber - 1;
                 return true;
             }
          });



       lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {   //--------position change to string
              if(pehlidafachalana == 0) {
                  pehlidafachalana = 1;
              }
              else {
                  li.set(lastselecteditemnumber, lastselectedvalue);                                //it is set previous value as is
              }

                lastselecteditemnumber = position;                                                  //it is for index
                lastselectedvalue = li.get(position);                                                 //it is value & it is save in some variable

                li.set(position,li.get(position)+"                "+phonenumber.get(position) );
                aA.notifyDataSetChanged();



                 Toast.makeText(getApplicationContext(),phonenumber.get(position),Toast.LENGTH_SHORT).show();
                 //ed.setText(phonenumber.get(position));
                 Log.i("Clicked",phonenumber.get(position));
             selecteditem = position;
             selectionkliyejhanda = 1;
            }
        });


        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.newEntry) {
            Intent nayapage = new Intent(this,Main2Activity.class);
            startActivity(nayapage);

            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
