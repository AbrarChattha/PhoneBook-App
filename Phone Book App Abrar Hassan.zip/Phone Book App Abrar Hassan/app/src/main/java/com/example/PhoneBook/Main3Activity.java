package com.example.PhoneBook;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.EditText;

public class Main3Activity extends AppCompatActivity {

    EditText etname;
    EditText etnumber;



    public void editkliye(View kuchb){
        String nayanam = etname.getText().toString();
        String nayanumber = etnumber.getText().toString();

        MainActivity.li.set(MainActivity.selectedpositionforedit,nayanam);
        MainActivity.phonenumber.set(MainActivity.selectedpositionforedit,nayanumber);
        MainActivity.aA.notifyDataSetChanged();

    }
    public void deletekliye(View kuchb){

        MainActivity.li.remove(MainActivity.selectedpositionforedit);
        MainActivity.phonenumber.remove(MainActivity.selectedpositionforedit);
        MainActivity.aA.notifyDataSetChanged();
        if (MainActivity.selectedpositionforedit == MainActivity.lastselecteditemnumber)
            MainActivity.pehlidafachalana = 0;
        else if (MainActivity.selectedpositionforedit < MainActivity.lastselecteditemnumber)
            MainActivity.lastselecteditemnumber = MainActivity.lastselecteditemnumber - 1;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        etname = findViewById(R.id.editTextname);
        etnumber =  findViewById(R.id.editTextnumber);

        etname.setText(MainActivity.li.get(MainActivity.selectedpositionforedit));
        etnumber.setText(MainActivity.phonenumber.get(MainActivity.selectedpositionforedit));


        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

}
