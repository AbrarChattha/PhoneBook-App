package com.example.PhoneBook;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class Main4Activity extends AppCompatActivity {

    EditText etname,etnumber;
    int aikkoivar;

    public void editkliye4(View kuchb){
        String nayanam = etname.getText().toString();
        String nayanumber = etnumber.getText().toString();

        MainActivity.li.set(aikkoivar,nayanam);
        //MainActivity.phonenumber.set(MainActivity.selectedpositionforedit,nayanumber);
        MainActivity.phonenumber.set(aikkoivar,nayanumber);
        MainActivity.aA.notifyDataSetChanged();

    }
    public void deletekliye4(View kuchb){

        MainActivity.li.remove(aikkoivar);
        MainActivity.phonenumber.remove(aikkoivar);
        MainActivity.aA.notifyDataSetChanged();
        if (aikkoivar == MainActivity.lastselecteditemnumber)
            MainActivity.pehlidafachalana = 0;
        else if (aikkoivar < MainActivity.lastselecteditemnumber)
            MainActivity.lastselecteditemnumber = MainActivity.lastselecteditemnumber - 1;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        etname = findViewById(R.id.koinaam);
        etnumber = findViewById(R.id.koinumber);

        Intent jomarzi = getIntent();
        aikkoivar = jomarzi.getIntExtra("aikKey", -1);

        if (aikkoivar == -1){
            Log.i("Msg","Koi data ni milla");
        }
        else
            etname.setText(MainActivity.li.get(aikkoivar));
            etnumber.setText(MainActivity.phonenumber.get(aikkoivar));

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

}
